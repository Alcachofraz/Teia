class Story {}
