import 'package:teia/models/snippets/snippet.dart';

class ChoiceSnippet extends Snippet {
  int pageId;
  ChoiceSnippet(text, this.pageId) : super(text);
}
