import 'package:teia/models/snippets/snippet.dart';

class RawSnippet extends Snippet {
  RawSnippet(text) : super(text);
}
