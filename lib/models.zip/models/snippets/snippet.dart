class Snippet {
  String text;
  Snippet(this.text);
}
