import 'package:teia/models/snippets/snippet.dart';

class Page {
  final int id;
  final List<Snippet> snippets;

  Page(this.id, this.snippets);
}
